from abc import ABC
from enum import Enum
from typing import Optional

import cv2
import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from matplotlib import pyplot as plt
from shapely import intersection, union
from shapely.geometry import Polygon, box as shapely_box
from torchvision import transforms
from ultralytics import YOLO
from ultralytics.engine.results import Boxes


# from app.utils.common import crop_image

def crop_image(
        image: np.ndarray,
        bbox: list[int | float]
):
    bbox = [int(x) for x in bbox]
    x1, y1, x2, y2 = bbox
    return image[y1:y2, x1:x2]


class BaseModel(ABC):
    """Base class for all YOLO-based detectors."""

    def __init__(self, model_path: str):
        self.model = YOLO(model_path)
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model.to(device)

    @staticmethod
    def get_crop(frame: np.ndarray, box: Boxes) -> np.ndarray:
        """Get cropped image based on detection box."""
        bbox = box.xyxy[0].tolist()
        return crop_image(frame, bbox)


class VehicleDetector(BaseModel):
    """Handles vehicle detection using YOLO model."""

    VEHICLE_CLASSES = [2, 3, 5, 7]

    def detect(self, frame: np.ndarray, roi: Polygon = None, visualize: bool = False) -> Optional[Boxes]:
        """
        Detect vehicles in the frame and return the single most relevant detection.

        Args:
            frame: Input image frame
            roi: Optional region of interest
            visualize: Whether to visualize the detection (default: False)

        Returns:
            Most relevant vehicle detection or None
        """
        detections = self.model.predict(frame, verbose=False, classes=self.VEHICLE_CLASSES)[0].boxes
        if not detections:
            return None

        if roi:
            max_iou = 0
            max_iou_index = 0

            for i, detection in enumerate(detections):
                # Convert YOLO bbox (x1, y1, x2, y2) to Shapely Polygon
                x1, y1, x2, y2 = detection.xyxy.squeeze().tolist()
                bbox_poly = shapely_box(x1, y1, x2, y2)

                # Calculate IoU using Shapely operations
                inter_area = intersection(bbox_poly, roi).area
                union_area = union(bbox_poly, roi).area
                iou = inter_area / union_area if union_area > 0 else 0

                if iou > max_iou:
                    max_iou = iou
                    max_iou_index = i

                if visualize:
                    # Create a copy of the frame to draw on
                    viz_frame = frame.copy()

                    # Convert to BGR if it's RGB
                    if viz_frame.shape[2] == 3 and np.max(viz_frame) <= 1.0:
                        viz_frame = (viz_frame * 255).astype(np.uint8)

                    if viz_frame.shape[2] == 3:
                        viz_frame = cv2.cvtColor(viz_frame, cv2.COLOR_RGB2BGR)

                    # Draw ROI if provided
                    if roi:
                        roi_coords = np.array(list(roi.exterior.coords)[:-1], dtype=np.int32)
                        cv2.polylines(viz_frame, [roi_coords], isClosed=True, color=(0, 255, 0), thickness=2)

                    # Draw detection bounding box
                    x1, y1, x2, y2 = detection.xyxy[0].int().tolist()
                    cv2.rectangle(viz_frame, (x1, y1), (x2, y2), color=(0, 0, 255), thickness=2)

                    # Display the image
                    plt.figure(figsize=(15, 10))
                    plt.imshow(cv2.cvtColor(viz_frame, cv2.COLOR_BGR2RGB))
                    plt.axis('off')
                    plt.tight_layout()
                    plt.show()

            if max_iou == 0:
                return None
            else:
                detection = detections[max_iou_index]
        else:
            def box_area(bbox):
                _, _, w, h = bbox.xywh[0].tolist()
                return w * h

            largest_area_index = max(range(len(detections)), key=lambda i: box_area(detections[i]))
            detection = detections[largest_area_index]

        # Visualization (optional)

        return detection


class PlateDetector(BaseModel):
    """Handles license plate detection using YOLO model."""

    def detect(self, image: np.ndarray) -> Optional[Boxes]:
        """
        Detect the license plate in a cropped vehicle region.
        """
        detections = self.model.predict(image, verbose=False, max_det=1)[0].boxes

        if len(detections) == 0:
            return None

        return max(detections, key=lambda box: box.conf.item())


class SymbolDetector(BaseModel):
    """Handles symbol detection within license plates using YOLO model."""

    def detect(self, image: np.ndarray) -> list[Boxes]:
        """
        Detect symbols within a cropped license plate region.
        """
        detections = self.model.predict(image, verbose=False, max_det=9, conf=0.5)[0].boxes

        return sorted(detections, key=lambda box: box.xyxy[0][0].item())


class FlagDetector(BaseModel):
    def has_flag(self, image: np.ndarray):
        """
        Detect flag of KZ within a cropped license plate region and returns True if flag is there.
        """
        detections = self.model.predict(image, verbose=False, max_det=1)

        if len(detections[0].boxes) == 0:
            return False
        else:
            return True


class PlateColor(str, Enum):
    white = 'white'
    yellow = 'yellow'


class PlateColorClassifier(BaseModel):
    def classify(self, image: np.ndarray) -> PlateColor:
        """
        Detect symbols within a cropped license plate region.
        """
        probs = self.model.predict(image, verbose=False)[0].probs.data.cpu().numpy()
        index_of_max = int(np.argmax(probs))
        return PlateColor(self.model.names[index_of_max])


class SymbolClassifier(BaseModel):
    """Handles classification of detected symbols."""

    def classify(self, frame: np.ndarray, symbols: list[Boxes], gray: bool = False) -> str:
        """Classify each detected symbol and return the concatenated string."""
        labels = []
        for i, symbol in enumerate(symbols):
            cropped_image = self.get_crop(frame, symbol)
            if gray:
                cropped_image = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2GRAY)
            # cv2.imwrite(f'{i}.jpg', cropped_image)
            probs = self.model.predict(cropped_image, verbose=False)[0].probs.data.cpu().numpy()
            index_of_max = int(np.argmax(probs))
            labels.append(self.model.names[index_of_max])
        return "".join(labels)


class CharType(Enum):
    digit = 'digit'
    letter = 'letter'


# Define plate templates as configuration
PLATE_TEMPLATES = {
    8: {
        'default': [CharType.digit, CharType.digit, CharType.digit, CharType.letter, CharType.letter,
                    CharType.letter, CharType.digit, CharType.digit]
    },
    7: {
        (PlateColor.white, True): [CharType.digit, CharType.digit, CharType.digit, CharType.letter, CharType.letter,
                                   CharType.digit, CharType.digit],
        (PlateColor.white, False): [CharType.letter, CharType.digit, CharType.digit, CharType.digit,
                                    CharType.letter, CharType.letter, CharType.letter],
        (PlateColor.yellow, None): [CharType.letter, CharType.digit, CharType.digit, CharType.digit, CharType.digit,
                                    CharType.digit, CharType.digit]
    },
    6: {
        (PlateColor.white, True): [CharType.digit, CharType.digit, CharType.digit, CharType.letter, CharType.letter,
                                   CharType.letter],
        (PlateColor.white, False): [CharType.letter, CharType.digit, CharType.digit, CharType.digit,
                                    CharType.letter, CharType.letter],
        (PlateColor.yellow, True): [CharType.digit, CharType.digit, CharType.digit, CharType.digit, CharType.digit,
                                    CharType.digit]
    }
}


class LPRProcessor:
    """Manager class that combines all detectors for license plate recognition."""

    def __init__(
            self,
            vehicle_detector_path: str,
            plate_detector_path: str,
            symbol_detector_path: str,
            symbol_classifier_path: str,
            flag_detector_path: str,
            plate_color_classifier_path: str,
            letter_classifier_path: str,
            digit_classifier_path: str,
    ):
        self.vehicle_detector = VehicleDetector(vehicle_detector_path)
        self.plate_detector = PlateDetector(plate_detector_path)
        self.symbol_detector = SymbolDetector(symbol_detector_path)
        self.symbol_classifier = SymbolClassifier(symbol_classifier_path)
        self.flag_detector = FlagDetector(flag_detector_path)
        self.plate_type_classifier = PlateColorClassifier(plate_color_classifier_path)
        self.letter_classifier = SymbolClassifierCNN(letter_classifier_path, 26)
        self.digit_classifier = SymbolClassifierCNN(digit_classifier_path, 10)

    def get_plate_text_template(self, plate_image: np.ndarray, n: int) -> Optional[list[CharType]]:
        """
        Determine the expected pattern of characters on a license plate.

        Args:
            plate_image: Image of the license plate
            n: Length of the plate text

        Returns:
            List of character types (digit or letter) or None if no template exists
        """
        if n not in PLATE_TEMPLATES:
            return None

        templates = PLATE_TEMPLATES[n]

        # For simple cases with only one template
        if 'default' in templates:
            return templates['default']

        # For cases that depend on plate color and flag
        plate_color = self.plate_type_classifier.classify(plate_image)
        has_flag = self.flag_detector.has_flag(plate_image) if n < 8 else None

        # Try to find a matching template
        template_key = (plate_color, has_flag)
        if template_key in templates:
            return templates[template_key]

        # Try with None instead of has_flag as a fallback
        template_key = (plate_color, None)
        if template_key in templates:
            return templates[template_key]

        return None

    @staticmethod
    def template_to_string(template: list[CharType]) -> str:
        """
        Convert a template of CharType enums to a string representation.

        Args:
            template: List of CharType enums

        Returns:
            String representation where 'd' = digit and 'l' = letter
        """
        if template is None:
            return "unknown"

        char_map = {
            CharType.digit: 'd',
            CharType.letter: 'l'
        }

        return ''.join(char_map[char_type] for char_type in template)

    def process_frame(
            self,
            frame: np.ndarray,
            roi: Optional[np.ndarray | list[list[int]]] = None
    ) -> dict:
        """
        Process a single frame to detect and recognize a license plate.

        Args:
            frame: Input image frame
            roi: Optional region of interest for vehicle detection

        Returns:
            dict: Dictionary containing intermediate detections and plate information
        """
        results = dict()

        # Prepare ROI if provided
        if roi is not None:
            if isinstance(roi, list):
                roi = np.array(roi)
            roi = Polygon(roi)

        # Detect vehicle
        vehicle = self.vehicle_detector.detect(frame, roi)
        if vehicle is None:
            return results

        results['vehicle'] = vehicle
        vehicle_image = self.vehicle_detector.get_crop(frame, vehicle)

        # Detect plate
        plate = self.plate_detector.detect(vehicle_image)
        if plate is None:
            return results

        results['plate'] = plate
        plate_image = self.plate_detector.get_crop(vehicle_image, plate)

        # Detect symbols
        symbols = self.symbol_detector.detect(plate_image)
        if symbols is None:
            return results

        results["symbols"] = symbols

        # Determine if processing should continue based on ROI
        if roi:
            x1, y1, x2, y2 = vehicle.xyxy.squeeze().tolist()
            bbox_poly = shapely_box(x1, y1, x2, y2)
            inter_area = intersection(bbox_poly, roi).area
            roi_area = roi.area
            ratio = inter_area / roi_area

            # Only process if vehicle significantly overlaps with ROI and plate meets criteria
            if not (ratio > 0.3 and plate.conf > 0.75 and len(symbols) > 6):
                return results

        # Attempt to get plate text template
        template = self.get_plate_text_template(plate_image, len(symbols))
        results["template"] = self.template_to_string(template)

        # Classify plate text
        if template is None:
            # If no template, use general symbol classifier
            plate_text = self.symbol_classifier.classify(plate_image, symbols)
        else:
            # Use specialized classifiers based on template
            predictions = []
            for i, s in enumerate(template):
                if s == CharType.letter:
                    pred = self.letter_classifier.classify(plate_image, [symbols[i]])
                else:
                    pred = self.digit_classifier.classify(plate_image, [symbols[i]])
                predictions.append(pred)
            plate_text = "".join(predictions)

        # Store and return plate number
        results['plate_number'] = plate_text
        return results


class Classifier(nn.Module):
    def __init__(self, n):
        super(Classifier, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 8 * 8, 128)
        self.fc2 = nn.Linear(128, n)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.5)

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        x = x.view(-1, 64 * 8 * 8)
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        return x


class SymbolClassifierCNN:
    def __init__(self, model_path, n, device=None):
        """
        Initialize the classifier with a trained model.

        Args:
            model_path (str): Path to the saved model checkpoint
            device (str, optional): Device to run inference on ('cuda' or 'cpu')
        """
        # Set device
        self.device = device if device else ('cuda' if torch.cuda.is_available() else 'cpu')
        # Initialize model
        self.model = Classifier(n).to(self.device)
        # Load model weights
        checkpoint = torch.load(model_path, map_location=self.device)
        if 'model_state_dict' in checkpoint:
            self.model.load_state_dict(checkpoint['model_state_dict'])
        else:
            self.model.load_state_dict(checkpoint)
        self.model.eval()
        # Setup image transformations
        self.transform = transforms.Compose([
            transforms.Grayscale(num_output_channels=1),
            transforms.Resize((32, 32)),
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))
        ])
        # Class mapping
        self.idx_to_class = self.create_idx_to_class(n)

    @staticmethod
    def create_idx_to_class(n: int):
        """
        Create mapping based on number of classes.

        Args:
            n (int): Number of classes (10 for digits, 26 for letters)

        Returns:
            dict: Mapping from index to character
        """
        if n == 10:  # digits
            return {i: str(i) for i in range(n)}
        elif n == 26:  # letters
            return {i: chr(65 + i) for i in range(n)}
        else:
            raise ValueError(f"Unsupported number of classes: {n}. Must be either 10 (digits) or 26 (letters)")

    @staticmethod
    def get_crop(frame: np.ndarray, box: Boxes) -> np.ndarray:
        """Get cropped image based on detection box."""
        bbox = box.xyxy[0].tolist()
        return crop_image(frame, bbox)

    def preprocess_image(self, image_array: np.ndarray) -> torch.Tensor:
        """
        Preprocess the input image array.

        Args:
            image_array (numpy.ndarray): Input image array (H, W, 3)

        Returns:
            torch.Tensor: Preprocessed image tensor
        """
        image = Image.fromarray(image_array.astype('uint8'))
        tensor = self.transform(image)
        tensor = tensor.unsqueeze(0)
        return tensor.to(self.device)

    @torch.no_grad()
    def classify(self, frame: np.ndarray, symbols: list[Boxes]):
        labels = []
        for i, symbol in enumerate(symbols):
            cropped_image = self.get_crop(frame, symbol)
            tensor = self.preprocess_image(cropped_image)
            outputs = self.model(tensor)
            _, predicted = outputs.max(1)
            predicted_class = self.idx_to_class[predicted.item()]

            labels.append(predicted_class)
        return "".join(labels)

    def __call__(self, image_array):
        """
        Allow the class to be called directly like a function.

        Args:
            image_array (numpy.ndarray): Input image array

        Returns:
            str: Predicted class
        """
        return self.classify(image_array)


def main_on_image():
    from settings import settings
    import cv2

    lpr_processor = LPRProcessor(
        vehicle_detector_path=str(settings.storage_folder / settings.vehicle_detector_ckpt),
        plate_detector_path=str(settings.storage_folder / settings.plate_detector_ckpt),
        symbol_detector_path=str(settings.storage_folder / settings.symbol_detector_ckpt),
        symbol_classifier_path=str(settings.storage_folder / settings.symbol_classifier_ckpt),
        flag_detector_path=str(settings.storage_folder / settings.flag_detector_ckpt),
        plate_color_classifier_path=str(settings.storage_folder / settings.plate_type_classifier_ckpt),
        letter_classifier_path=str(settings.storage_folder / settings.letter_classifier_ckpt),
        digit_classifier_path=str(settings.storage_folder / settings.digit_classifier_ckpt),
    )
    # frame_path = storage_dir.joinpath("images/test7.jpg")
    # frame_path = settings.project_folder.joinpath("t.jpg")
    frame_path = "/Users/y.orazayev/relive/lpr_service/t.jpg"
    # frame_path = "/Users/y.orazayev/relive/lpr_service/notebooks/jun_21_24_atyrau/880 OOO 06.jpeg"
    frame = cv2.imread(str(frame_path))
    results = lpr_processor.process_frame(
        frame,
        # [[865, 1072], [947, 1154], [1427, 1080], [1320, 1021]],
    )
    print(results["template"])


def main_on_video():
    from settings import settings
    import cv2
    from tqdm import tqdm

    lpr_processor = LPRProcessor(
        vehicle_detector_path=str(settings.storage_folder / settings.vehicle_detector_ckpt),
        plate_detector_path=str(settings.storage_folder / settings.plate_detector_ckpt),
        symbol_detector_path=str(settings.storage_folder / settings.symbol_detector_ckpt),
        symbol_classifier_path=str(settings.storage_folder / settings.symbol_classifier_ckpt),
        flag_detector_path=str(settings.storage_folder / settings.flag_detector_ckpt),
        plate_color_classifier_path=str(settings.storage_folder / settings.plate_type_classifier_ckpt),
        letter_classifier_path=str(settings.storage_folder / settings.letter_classifier_ckpt),
        digit_classifier_path=str(settings.storage_folder / settings.digit_classifier_ckpt),
    )

    input_video_path = "/Users/y.orazayev/relive/lpr_service/hikvision_stream.mp4"
    output_video_path = "/Users/y.orazayev/relive/lpr_service/hikvision_stream_p.mp4"

    cap = cv2.VideoCapture(input_video_path)
    if not cap.isOpened():
        print("Error: Could not open video.")
        exit()

    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (frame_width // 2, frame_height // 2))

    roi = np.array([[837, 1085], [892, 1230], [1309, 1089]])

    with tqdm(total=frame_count, desc="Processing Video") as pbar:
        try:
            current_frame = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                current_frame += 1
                frame_text = f"{current_frame}/{frame_count}"
                cv2.putText(frame, frame_text, (10, 300), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 2,
                            cv2.LINE_AA)

                cv2.polylines(frame, [roi], isClosed=True, color=(255, 0, 0), thickness=2)
                plate_text, results = lpr_processor.process_frame(frame, roi)

                vehicle_result = results['vehicle']
                if vehicle_result is not None:
                    x1, y1, x2, y2 = map(int, vehicle_result.xyxy[0])
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
                    cv2.polylines(frame, [roi], isClosed=True, color=(0, 255, 0), thickness=2)
                if plate_text is not None:
                    cv2.putText(
                        frame, plate_text, (10, 400), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 2, cv2.LINE_AA
                    )
                resized_frame = cv2.resize(frame, (frame.shape[1] // 2, frame.shape[0] // 2))
                out.write(resized_frame)
                # cv2.imshow("Frame", frame)
                # if cv2.waitKey(1) & 0xFF == ord('q'):
                #     break
                pbar.update(1)

        finally:
            cap.release()
            out.release()
            cv2.destroyAllWindows()

    print('Processing completed')


def check_for_vehicle():
    from settings import settings
    import cv2
    import numpy as np

    storage_dir = settings.storage_folder
    vehicle_detector = VehicleDetector(
        model_path=str(storage_dir.joinpath(settings.vehicle_detection_path)),
    )

    input_video_path = ""

    cap = cv2.VideoCapture(input_video_path)
    if not cap.isOpened():
        print("Error: Could not open video.")
        exit()

    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    roi = np.array([[398, 835], [1875, 1368], [2194, 978], [777, 782]])
    current_frame = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        current_frame += 1

        result = vehicle_detector.detect(frame, Polygon(roi))
        frame_text = f"{current_frame}/{frame_count}"
        cv2.putText(frame, frame_text, (10, 300), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 2, cv2.LINE_AA)

        if result is not None:
            # result, iou = result
            for box in result:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
            cv2.polylines(frame, [roi], isClosed=True, color=(255, 0, 0), thickness=2)
            # cv2.putText(frame, str(iou), (10, 400), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 2, cv2.LINE_AA)
        else:
            cv2.polylines(frame, [roi], isClosed=True, color=(0, 255, 0), thickness=2)
        cv2.imshow("Frame", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    # check_for_vehicle()
    # main_on_video()
    main_on_image()
    # pass
