import csv
import io
import json
import time
from typing import Annotated

import numpy as np
from PIL import Image
from fastapi import APIRouter, File, HTTPException, Form
from loguru import logger

from app.lpr import models as models
from app.lpr import schemas
from app.utils.common import identify_task_stage
from settings import settings

router = APIRouter(
    prefix='/lpr',
    tags=['lpr'],
)

storage_dir = settings.storage_folder
model = models.LPRProcessor(
    vehicle_detector_path=str(settings.storage_folder / settings.vehicle_detector_ckpt),
    plate_detector_path=str(settings.storage_folder / settings.plate_detector_ckpt),
    symbol_detector_path=str(settings.storage_folder / settings.symbol_detector_ckpt),
    symbol_classifier_path=str(settings.storage_folder / settings.symbol_classifier_ckpt),
    flag_detector_path=str(settings.storage_folder / settings.flag_detector_ckpt),
    plate_color_classifier_path=str(settings.storage_folder / settings.plate_type_classifier_ckpt),
    letter_classifier_path=str(settings.storage_folder / settings.letter_classifier_ckpt),
    digit_classifier_path=str(settings.storage_folder / settings.digit_classifier_ckpt),
)

logger.info(f"Vehicle detector model device: {model.vehicle_detector.model.device}")
logger.info(f"Letter classifier model device: {model.letter_classifier.device}")


@router.post(
    "/process_frame",
    response_model=schemas.LPROutput,
)
async def process_frame(
        frame: Annotated[bytes, File()],
        roi_coords: Annotated[str, Form()] = "[]",
) -> schemas.LPROutput:
    log_file = storage_dir / "lpr_processing_times.csv"
    start_time = time.time()

    # Validate coordinates
    coords_list = json.loads(roi_coords)
    if not isinstance(coords_list, list) or not all(isinstance(sublist, list) for sublist in coords_list):
        raise HTTPException(status_code=422, detail="Coordinates must be a list of lists")
    # logger.info(f"ROI coords: {coords_list}")

    # Process image
    pil_image = Image.open(io.BytesIO(frame))
    frame = np.array(pil_image)
    result = model.process_frame(frame, coords_list)
    processing_time = time.time() - start_time
    task_stage = identify_task_stage(result)
    try:
        file_exists = log_file.exists()

        with open(log_file, 'a', newline='') as csvfile:
            csvwriter = csv.writer(csvfile)

            if not file_exists:
                csvwriter.writerow(['actual_time', 'processing_time', 'task_stage'])

            csvwriter.writerow(
                [
                    time.strftime('%Y-%m-%d %H:%M:%S'),
                    f"{processing_time:.4f}",
                    task_stage,
                ]
            )

    except Exception as e:
        # Log error but don't interrupt the main flow
        logger.error(f"Error writing to CSV: {e}")
    # Check vehicle detection
    if not result.get("vehicle", None):
        logger.warning(f"No vehicle detected in frame.")
        raise HTTPException(status_code=404, detail="No vehicle is detected")

    # Check plate detection
    if not result.get("plate", None):
        logger.warning(f"No plate is detected")
        raise HTTPException(status_code=404, detail="No plate is detected")

    # Get plate number
    plate_number = result.get("plate_number", None)
    if plate_number is None:
        logger.warning(f"Plate is not readable from this view")
        raise HTTPException(status_code=404, detail="Plate is not readable from this view")

    logger.success(f"Plate number: {plate_number}")
    # Return result
    return schemas.LPROutput(
        plate_number=plate_number,
    )


async def main_stream():
    import cv2
    cap = cv2.VideoCapture(0)
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.5
    font_color = (0, 255, 255)
    thickness = 1

    while cap.isOpened():
        ret, frame = cap.read()
        if ret:
            frame = cv2.flip(frame, 1)
            _, encoded_frame = cv2.imencode('.jpg', frame)
            try:
                output = await process_frame(
                    frame=encoded_frame.tobytes(),
                )
                cv2.putText(frame, output.plate_number, (50, 50), font, font_scale, font_color, thickness)
            except Exception as e:
                logger.exception(e)
            cv2.imshow('frame', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
    cap.release()
    cv2.destroyAllWindows()


async def main_image():
    import cv2

    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1
    font_color = (255, 0, 0)
    thickness = 1

    # file_path = settings.storage_folder.joinpath('images/test7.jpg')
    # file_path = "/home/tumar/Documents/test_omarova.jpg"
    file_path = settings.storage_folder.joinpath('images/car_lexus.jpg')
    roi = [[865, 1072], [947, 1154], [1427, 1080], [1320, 1021]]

    with open(file_path, 'rb') as f:
        frame_bytes = f.read()

    try:
        output = await process_frame(
            frame=frame_bytes,
            roi_coords="[[865, 1072], [947, 1154], [1427, 1080], [1320, 1021]]",
        )
        frame = cv2.imread(str(file_path))
        logger.success(output.plate_number)
        cv2.putText(frame, output.plate_number, (50, 150), font, font_scale, font_color, thickness)
        cv2.imshow('frame', frame)
        cv2.waitKey(0)
    except Exception as e:
        logger.exception(e)


async def main_request():
    import httpx

    url = f'{settings.server.url}/lpr/process_frame'
    # file_path = settings.storage_folder.joinpath('images/cars.jpg')
    file_path = settings.storage_folder.joinpath('images/car_lexus.jpg')

    files = {'frame': (file_path, open(file_path, 'rb'), 'image/jpeg')}
    headers = {'accept': 'apmodel_pathplication/json'}

    response = httpx.post(url, files=files, headers=headers)

    print(response.status_code)
    print(response.json())


if __name__ == '__main__':
    import asyncio

    asyncio.run(main_image())
