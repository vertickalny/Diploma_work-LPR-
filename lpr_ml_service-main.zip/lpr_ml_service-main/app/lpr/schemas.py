from pydantic import BaseModel


class LPROutput(BaseModel):
    plate_number: str
