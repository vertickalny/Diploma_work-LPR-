import numpy as np
from fastapi import HTTPException, Security
from fastapi.security import APIKeyHeader
from starlette import status

from settings import settings

base_folder = settings.project_folder
app_folder = settings.project_folder / 'app'

api_key_header = APIKeyHeader(name="X-API-Key")
server_api_key = settings.server_api_key


def get_api_key(api_key: str = Security(api_key_header)) -> str:
    if api_key == server_api_key:
        return api_key
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or missing API Key",
    )


def collect_paths(pattern: str):
    for model_file in list(app_folder.rglob(pattern)):
        model_file = model_file.relative_to(base_folder)
        module_path = str(model_file.with_suffix('')).replace('/', '.')
        yield module_path


def crop_image(
        image: np.ndarray,
        bbox: list[int | float]
):
    bbox = [int(x) for x in bbox]
    x1, y1, x2, y2 = bbox
    return image[y1:y2, x1:x2]


def identify_task_stage(result: dict) -> str:
    """
    Identify the task stage based on the processing result.

    Args:
        result (dict): The result from process_frame method

    Returns:
        str: The identified task stage
    """
    if 'vehicle' not in result:
        return 'no_vehicle_detected'

    if 'plate' not in result:
        return 'no_plate_detected'

    if 'symbols' not in result:
        return 'no_symbol_detected'

    if 'template' not in result:
        return 'no_templated_cls'

    return 'templated_cls'
