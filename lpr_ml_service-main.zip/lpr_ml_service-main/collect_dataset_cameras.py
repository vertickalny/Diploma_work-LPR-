import time
from datetime import datetime

import cv2

from app.lpr.models import LPRProcessor
from settings import settings

dataset_dir = settings.project_folder.joinpath('collected_data')
dataset_dir.mkdir(parents=True, exist_ok=True)
storage_dir = settings.storage_folder

lpr_processor = LPRProcessor(
    vehicle_detector_path=str(storage_dir.joinpath(settings.vehicle_detector_ckpt)),
    plate_detector_path=str(storage_dir.joinpath(settings.plate_detector_ckpt)),
    symbol_detector_path=str(storage_dir.joinpath(settings.symbol_detector_ckpt)),
    symbol_classifier_path=str(storage_dir.joinpath(settings.symbol_classifier_ckpt)),
    flag_detector_path=str(storage_dir.joinpath(settings.flag_detector_ckpt)),
    plate_color_classifier_path=str(storage_dir.joinpath(settings.plate_type_classifier_ckpt)),
    letter_classifier_path=str(storage_dir.joinpath(settings.letter_classifier_ckpt)),
    digit_classifier_path=str(storage_dir.joinpath(settings.digit_classifier_ckpt)),
)

username = 'admin'
password = 'qwerty12'
ip = '45.133.232.194'

ports_mapping = {
    "in_syganak": 581,
    "out_syganak": 582,
    "in_omarova": 583,
    "out_omarova": 584,
}

polygon_mappings = {
    "in_syganak": [[523, 966], [656, 1064], [1226, 942], [1053, 891]],
    "out_syganak": [[982, 859], [1108, 993], [1863, 887], [1654, 781]],
    "in_omarova": [[1085, 1195], [916, 1015], [1749, 924], [1953, 1019]],
    "out_omarova": [[920, 761], [1089, 895], [1753, 777], [1576, 675]],
}


def save_vehicle_frames(barrier_gate: str):
    port = ports_mapping[barrier_gate]
    rtsp_url = f"rtsp://{username}:{password}@{ip}:{port}/stream"
    current_date = datetime.now()
    day_month_year = current_date.strftime("%d-%m-%Y")
    output_dir = dataset_dir.joinpath(barrier_gate, f"{day_month_year}")
    output_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(rtsp_url)
    if not cap.isOpened():
        print("Error: Could not open video.")
        exit()
    roi = polygon_mappings[barrier_gate]
    last_capture_time = 0  # Start at 0 to allow first frame to be processed
    previous_plate_number = ""
    count = 1
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            current_time = time.time()
            if current_time - last_capture_time >= 2.0:
                results = lpr_processor.process_frame(frame, roi)
                plate_number = results.get("plate_number", None)
                if plate_number:
                    if plate_number != previous_plate_number:
                        template = lpr_processor.template_to_string(results["template"])
                        filename = f"{str(output_dir.joinpath(datetime.now().strftime('%Y%m%d_%H%M%S')))}_{template}_{roi}_{plate_number}.jpg"
                        cv2.imwrite(filename, frame)
                        print(
                            count,
                            f":       {datetime.now().strftime('%Y%m%d_%H%M%S')}, {template} - Plate: {plate_number}",
                        )

                        count += 1
                        last_capture_time = current_time
                        previous_plate_number = plate_number

    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    save_vehicle_frames(barrier_gate='in_omarova')
