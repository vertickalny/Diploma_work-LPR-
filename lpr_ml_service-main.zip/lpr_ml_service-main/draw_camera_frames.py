from datetime import datetime

import cv2
import numpy as np
from shapely import intersection
from shapely.geometry import Polygon, box as shapely_box

from app.lpr.models import LPRProcessor
from settings import settings

dataset_dir = settings.project_folder.joinpath('collected_data')
dataset_dir.mkdir(parents=True, exist_ok=True)
storage_dir = settings.storage_folder

lpr_processor = LPRProcessor(
    vehicle_detector_path=str(storage_dir.joinpath(settings.vehicle_detector_ckpt)),
    plate_detector_path=str(storage_dir.joinpath(settings.plate_detector_ckpt)),
    symbol_detector_path=str(storage_dir.joinpath(settings.symbol_detector_ckpt)),
    symbol_classifier_path=str(storage_dir.joinpath(settings.symbol_classifier_ckpt)),
    flag_detector_path=str(storage_dir.joinpath(settings.flag_detector_ckpt)),
    plate_color_classifier_path=str(storage_dir.joinpath(settings.plate_type_classifier_ckpt)),
    letter_classifier_path=str(storage_dir.joinpath(settings.letter_classifier_ckpt)),
    digit_classifier_path=str(storage_dir.joinpath(settings.digit_classifier_ckpt)),
)

username = 'admin'
password = 'qwerty12'
ip = '45.133.232.194'

ports_mapping = {
    "in_syganak": 581,
    "out_syganak": 582,
    "in_omarova": 583,
    "out_omarova": 584,
}

polygon_mappings = {
    "in_syganak": [[523, 966], [656, 1064], [1226, 942], [1053, 891]],
    "out_syganak": [[982, 859], [1108, 993], [1863, 887], [1654, 781]],
    "in_omarova": [[1085, 1195], [916, 1015], [1749, 924], [1953, 1019]],
    "out_omarova": [[601, 924], [680, 1007], [1148, 924], [1069, 865]],
}


def save_vehicle_frames(barrier_gate: str):
    port = ports_mapping[barrier_gate]
    rtsp_url = f"rtsp://{username}:{password}@{ip}:{port}/stream"
    current_date = datetime.now()
    day_month_year = current_date.strftime("%d-%m-%Y")
    output_dir = dataset_dir.joinpath(barrier_gate, f"{day_month_year}")
    output_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(rtsp_url)
    if not cap.isOpened():
        print("Error: Could not open video.")
        exit()
    polygon = polygon_mappings[barrier_gate]
    roi = np.array(polygon)
    roi_shapely = Polygon(roi)
    roi_area = roi_shapely.area
    count = 0
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            # Create a copy of the frame to draw on
            draw_frame = frame.copy()

            # Draw ROI polygon
            cv2.polylines(draw_frame, [roi.reshape((-1, 1, 2))], isClosed=True, color=(0, 255, 0), thickness=2)

            results = lpr_processor.process_frame(frame, roi)

            vehicle_bbox = results.get('vehicle', None)
            plate_bbox = results.get('plate', None)
            symbols = results.get("symbols", None)

            if vehicle_bbox is not None and plate_bbox is not None and symbols is not None:
                # Get vehicle bounding box coordinates
                x1, y1, x2, y2 = vehicle_bbox.xyxy.squeeze().tolist()
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

                # Draw vehicle bounding box
                cv2.rectangle(draw_frame, (x1, y1), (x2, y2), (255, 0, 0), 2)

                # Get plate bounding box coordinates
                plate_x1, plate_y1, plate_x2, plate_y2 = plate_bbox.xyxy.squeeze().tolist()
                plate_x1, plate_y1, plate_x2, plate_y2 = int(plate_x1), int(plate_y1), int(plate_x2), int(plate_y2)

                # Draw plate bounding box
                cv2.rectangle(draw_frame, (plate_x1, plate_y1), (plate_x2, plate_y2), (0, 0, 255), 2)

                # Calculate intersection ratio
                bbox_poly = shapely_box(x1, y1, x2, y2)
                inter_area = intersection(bbox_poly, roi_shapely).area
                ratio = inter_area / roi_area

                # Check conditions for saving
                if ratio > 0.3 and plate_bbox.conf > 0.75 and len(symbols) > 6:
                    save_path = output_dir.joinpath(f"{datetime.now()}.jpg")
                    cv2.imwrite(str(save_path), draw_frame)
                    print(count, f":       {save_path}", )
                    count += 1

            # Optional: Display the frame with bounding boxes in real-time
            cv2.imshow('Vehicle and Plate Detection', draw_frame)

            # Break the loop if 'q' is pressed
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    save_vehicle_frames(barrier_gate='out_omarova')