from pathlib import Path

import httpx
from loguru import logger

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

env_file = Path(__file__).parent / '.env'
env_file_encoding = 'utf-8'


class HostPort(BaseSettings):
    host: str
    port: str


class Server(HostPort):
    @property
    def url(self):
        return httpx.URL(f'http://{self.host}:{self.port}')

    model_config = SettingsConfigDict(
        env_prefix='SERVER_',
        env_file=env_file,
        env_file_encoding=env_file_encoding,
        extra='ignore',
    )


class HostPortUserPass(HostPort):
    username: str
    password: str


class Settings(BaseSettings):
    project_folder: Path = Field(..., alias='PROJECT_DIR')
    storage_folder: Path = Field(..., alias='STORAGE_DIR')
    vehicle_detector_ckpt: str = Field(..., alias='VEHICLE_DETECTOR_CHECKPOINT')
    plate_detector_ckpt: str = Field(..., alias='PLATE_DETECTOR_CKPT')
    symbol_detector_ckpt: str = Field(..., alias='SYMBOL_DETECTOR_CKPT')
    symbol_classifier_ckpt: str = Field(..., alias='SYMBOL_CLASSIFIER_CKPT')
    flag_detector_ckpt: str = Field(..., alias='FLAG_DETECTOR_CKPT')
    plate_type_classifier_ckpt: str = Field(..., alias='PLATE_TYPE_CLASSIFIER_CKPT')
    letter_classifier_ckpt: str = Field(..., alias='LETTER_CLASSIFIER_CKPT')
    digit_classifier_ckpt: str = Field(..., alias='DIGIT_CLASSIFIER_CKPT')
    server_api_key: str = Field(..., alias='SERVER_API_KEY')

    server: Server

    @field_validator('project_folder', 'storage_folder')
    def resolve_path(cls, v):
        path = Path(v).resolve()
        logger.debug("path: {}", path)
        assert path.exists(), f"Path does not exist: {path}"
        return path

    model_config = SettingsConfigDict(
        env_file=env_file,
        env_file_encoding=env_file_encoding,
        extra='ignore',
    )


settings = Settings(
    server=Server(),
)
