import cv2

# Replace with your Hikvision camera's details
username = 'admin'
password = 'qwerty12'


def external_ip_save():
    ip = '45.133.232.194'
    ports_mapping = {
        "in_syganak": 581,
        "out_syganak": 582,
        "in_omarova": 583,
        "out_omarova": 584,
    }
    for barrier_gate, port in ports_mapping.items():

        rtsp_url = f"rtsp://{username}:{password}@{ip}:{port}/stream"
        cap = cv2.VideoCapture(rtsp_url)
        if not cap.isOpened():
            print("Failed to open the stream.")
        else:
            ret, frame = cap.read()
            if ret:
                # Save the captured frame as an image file
                cv2.imwrite(f'{barrier_gate}.jpg', frame)
                print("Frame captured successfully.")
            else:
                print("Failed to retrieve frame.")

        # Release resources
        cap.release()
        cv2.destroyAllWindows()


def internal_ip_save():
    internal_ip_mapping = {
        "in_syganak": 197,
        "out_syganak": 198,
        "in_omarova": 199,
        "out_omarova": 200,
    }
    port = 554
    for barrier_gate, ip in internal_ip_mapping.items():

        rtsp_url = f"rtsp://{username}:{password}@192.168.8.{ip}:{port}/stream"
        cap = cv2.VideoCapture(rtsp_url)
        if not cap.isOpened():
            print("Failed to open the stream.")
        else:
            ret, frame = cap.read()
            if ret:
                # Save the captured frame as an image file
                cv2.imwrite(f'{barrier_gate}.jpg', frame)
                print("Frame captured successfully.")
            else:
                print("Failed to retrieve frame.")

        # Release resources
        cap.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    external_ip_save()
    # internal_ip_save()
